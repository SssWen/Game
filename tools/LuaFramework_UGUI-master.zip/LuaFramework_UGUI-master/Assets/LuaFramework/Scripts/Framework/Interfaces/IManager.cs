﻿/* 
 LuaFramework Code By Jarjin leeibution 3.0 License 
*/

using UnityEngine;
using System.Collections;

public interface IManager {
}
