﻿using System;

public interface IView {
    void OnMessage(IMessage message);
}
